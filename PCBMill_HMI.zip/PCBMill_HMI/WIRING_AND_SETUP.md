# PCBMillv1.0 — ESP32 HMI

For Ethan and Chase. ESP32 DevKit V1 with ESP32-WROOM-32 module, parallel 1602 LCD, KY-040 encoder, SPI microSD reader, and a separate Arduino Uno/CNC shield running GRBL 1.1. Upload PCBMill_HMI.ino to the ESP32. The Uno keeps its GRBL firmware.

## LCD pins 1–16

Verify the printed pin labels and pin-1 marking on your particular LCD. The sketch uses parallel 4-bit mode and LiquidCrystal by Arduino.

| LCD pin | Label | Connection |
|---|---|---|
| 1 | VSS | Common GND |
| 2 | VDD | LCD-rated supply, normally regulated 5 V |
| 3 | VO | Contrast voltage, usually near ground for a 5 V LCD |
| 4 | RS | ESP32 GPIO21, through level buffer if required below |
| 5 | RW | GND permanently |
| 6 | E | ESP32 GPIO22, through level buffer if required |
| 7 | D0 | Unconnected |
| 8 | D1 | Unconnected |
| 9 | D2 | Unconnected |
| 10 | D3 | Unconnected |
| 11 | D4 | ESP32 GPIO25, through level buffer if required |
| 12 | D5 | ESP32 GPIO26, through level buffer if required |
| 13 | D6 | ESP32 GPIO27, through level buffer if required |
| 14 | D7 | ESP32 GPIO13, through level buffer if required |
| 15 | A / LED+ | Backlight supply with current limiting specified for your module |
| 16 | K / LED− | Common GND |

The phrase “1602” identifies size, not the controller's electrical requirements. For a 5 V module whose input-high specification is unknown, buffer the six output signals through a 74AHCT244 powered at 5 V. This accepts 3.3 V inputs and gives the LCD 5 V logic. A 74HC244 has different thresholds and is not an equivalent choice here.

Optional robust LCD buffer wiring, for a standard 20-pin 74AHCT244 package:

| ESP32 input to buffer | Buffer input | Buffer output | LCD pin |
|---|---|---|---|
| GPIO21 | 2 | 18 | 4 |
| GPIO22 | 4 | 16 | 6 |
| GPIO25 | 6 | 14 | 11 |
| GPIO26 | 8 | 12 | 12 |
| GPIO27 | 11 | 9 | 13 |
| GPIO13 | 13 | 7 | 14 |

Buffer pin 20 = 5 V, pin 10 = GND, enable pins 1 and 19 = GND. Tie unused inputs 15 and 17 to GND. Leave outputs 5 and 3 unconnected. Put a 100 nF bypass capacitor between pins 20 and 10. Verify the exact part datasheet and package pinout.

A 10 kΩ contrast trimmer across LCD VDD/GND with its wiper on LCD pin 3 is conventional. It only sets display contrast; the KY-040 operates the HMI. For an initial test you can try pin 3 at GND; some modules then show excessively dark blocks and need an adjustable or fixed-divider contrast voltage. Backlight resistor requirements depend on whether your LCD includes one. Do not assume it does.

## Encoder

| KY-040 pin | ESP32 |
|---|---|
| + | 3V3 |
| GND | GND |
| CLK | GPIO32 |
| DT | GPIO33 |
| SW | GPIO14 |

Power the encoder at 3.3 V because module pull-ups connect to its supply. The sketch also enables internal pull-ups. Swap CLK/DT or change ENCODER_DIRECTION to -1 if the direction is reversed. Change TRANSITIONS_PER_DETENT from 4 to 2 only if it takes two physical clicks to advance one menu entry.

## SPI microSD

| Module pin | ESP32 |
|---|---|
| CS | GPIO4 |
| SCK | GPIO18 |
| MOSI | GPIO23 |
| MISO | GPIO19 |
| GND | GND |
| VCC | Determined by the exact module, as below |

Bare 3.3 V card adapters require 3.3 V power and logic. Modules with an onboard regulator may require 5 V at VCC. Six pins alone do not identify the design. Verify its product specification or regulator/level-shifter markings before wiring VCC. Its MISO output must be ESP32-compatible 3.3 V logic. This is the remaining module-specific wiring dependency.

Format the card as FAT32. Place files in the root directory. The browser lists up to 48 files ending in .ngc, .nc, .gcode, or .tap. Short, distinctive filenames work best on a 16-column screen. Choose Run SD file after inserting the card. A six-pin reader usually has no card-detect signal; the menu retries initialization each time it is selected. Keep the card inserted for the entire job.

## Uno serial link

GRBL uses 115200 baud, 8N1. Cross transmit and receive and connect grounds.

| Signal | Wiring |
|---|---|
| Uno D1/TX to ESP32 GPIO16/RX | Uno TX → 10 kΩ → junction → GPIO16; junction → 20 kΩ → GND. This divides nominal 5 V to about 3.33 V. |
| ESP32 GPIO17/TX to Uno D0/RX | Through a 3.3-to-5 V UART buffer such as a 74AHCT125 powered at 5 V |
| Ground | Uno GND ↔ ESP32 GND |

For channel 1 of a standard 14-pin 74AHCT125, pin 14 = 5 V, pin 7 = GND, pin 1 (/OE) = GND, pin 2 (input) = ESP32 GPIO17, pin 3 (output) = Uno D0. Decouple pins 14/7 with 100 nF. Disable unused channels by tying their /OE pins high and inputs to GND. Verify the package datasheet. The upward buffer gives a guaranteed 5 V logic level at the Uno receiver.

The Uno USB-to-serial interface also drives D0. Isolate its TX-to-D0 connection while the ESP32 sender is connected. Simply closing Serial Monitor or unplugging USB may leave the onboard bridge powered by the Uno's supply. Depending on the board, this can require a switch/jumper, removing the bridge's series resistor, or an appropriate UART multiplexer. Use the board schematic to identify the connection. For uploading GRBL from a PC, reconnect the bridge and disconnect the HMI transmitter. Do not run two G-code senders simultaneously.

Power each board with a suitable regulated supply and connect their grounds. Avoid tying separately powered 5 V USB supply outputs together. The CNC shield motor supply goes to its designated motor-power input, with voltage matched to its drivers and motors. ESP32 GPIOs are 3.3 V signals.

## Probe and homing

On the default Uno GRBL 1.1 mapping, the probe input is A5. Wire the normally open probe contact between A5 and GND. Confirm shield routing and GRBL build before using a shield-labeled connector. The probe must be open initially and close on contact. Verify GRBL's Pn:P status when manually actuating it. The default $6=0 configuration suits the usual normally open probe-to-ground wiring.

Probe Zero assumes the contact surface is exactly 14.000 mm above the intended work Z zero. It stops the spindle, sets millimeter reporting ($13=0), selects G21/G90/G54/G49, clears G92, probes downward at 30 mm/min up to 10 mm, and uses the successful PRB machine-coordinate Z to write the G54 offset. It retracts upward 2 mm and restores absolute distance mode. At trigger contact work Z is +14 mm; after retract it is approximately +16 mm. Verify the actual probe geometry and edit PROBE_HEIGHT_MM if needed. Position the tool above the probe with contact within the configured 10 mm travel. The probe's ability to tolerate overtravel and the machine's available retract space still matter.

Probe failure or GRBL error aborts the operation. The offset is written only after a successful PRB result. A later failure during retract can occur after the new offset has been written; inspect/re-probe before proceeding.

Auto Home sends $H and relies on correctly installed switches and configured GRBL homing settings. The sketch does not enable homing automatically. On default GRBL 1.1 with spindle PWM, X limit is D9, Y is D10, Z is D12, and spindle PWM is D11. Older CNC-shield silkscreens can disagree with these assignments. Configure $22, homing direction, travel, and rates for your actual machine before use. Homing usually requires a Z switch as well as X/Y switches for the standard 3-axis cycle.

Set XY zero was added so an SD-only workflow can place the G-code origin. Jog to the intended XY origin and select it. This selects G54 and sets the current X/Y work coordinates to zero. Probe Zero separately establishes Z. Homing establishes machine coordinates; the G54 work origin must still be set for the job.

## Install and upload

1. Add the Espressif board-manager URL in Arduino IDE preferences if needed:
   https://espressif.github.io/arduino-esp32/package_esp32_index.json
2. In Boards Manager install esp32 by Espressif Systems. Select DOIT ESP32 DEVKIT V1 and the ESP32's COM port.
3. In Library Manager install LiquidCrystal by Arduino. SPI, SD, and HardwareSerial come with the ESP32 core.
4. Open PCBMill_HMI/PCBMill_HMI.ino, keeping the folder and sketch basename identical.
5. Upload to the ESP32. If needed, hold BOOT while the IDE is connecting, then release after upload begins.
6. Serial Monitor on the ESP32 at 115200 shows GRBL responses and commands, including full errors that may be truncated on the LCD.

## Operation

Boot shows PCBMillv1.0 for four seconds. The author line “by Ethan and Chase” is 18 characters, so it scrolls horizontally.

Turn the encoder to choose an item. Short press selects. Long press for 1.2 seconds returns to the main menu while idle. During a job, probe, home, or jog it aborts/reset-clears GRBL. This is a software control and has button/communication latency. Provide the machine's physical emergency-stop function separately.

Main menu:

- Run SD file → file selection → feed target, Start job, Back.
- Manual jog → X/Y/Z → 0.01, 0.1, 1, or 10 mm → turn to move and click to leave.
- Auto home → Cancel/Yes.
- Probe zero → Cancel/Yes, using the 14 mm probe.
- Set XY zero → Cancel/Yes.
- Unlock alarm → Cancel/Yes. $X clears the alarm lock; it does not establish machine position. Use Auto Home to establish position when required.
- Bed leveling → informational “Leveling off” message. No grid probing or compensation is implemented in this version.

Jogging sends a single $J incremental move, waits for acknowledgment and Idle, and discards extra wheel movement while busy. This deliberately prevents queued jogging after you stop turning. XY uses 300 mm/min and Z uses 100 mm/min. Adjust the constants/values for your mechanics.

Feed target changes in 5% steps from 10–200%. It uses GRBL 1.1 realtime override commands and shows the actual reported percentage. Convergence to a distant target can take several seconds. It changes cutting-feed override; rapid moves and spindle speed have separate controls in GRBL.

During a job, rotate to Adjust feed, Pause/Resume, or Stop job, then press. Resume becomes effective after GRBL reports Hold:0. The screen's Sent percentage is bytes read/sent from the file, not elapsed time or completed cutting distance. It displays Finishing motion at EOF and waits for a fresh Idle report before declaring completion.

Pause uses GRBL feed hold; spindle behavior follows GRBL's configured behavior. Stop aborts with a soft reset and clears queued motion. Reset during motion may lose position; re-home and re-establish work setup before restarting. Door or externally triggered hold states block further streaming.

## File compatibility and limits

Use GRBL-compatible G-code. The sender passes motion and arc commands to GRBL, strips comments and whitespace, skips percent-marker lines, and rejects commands longer than 79 characters after stripping. A file error, unsupported command reported by GRBL, failed SD read, alarm, or lost status link stops streaming and resets GRBL. G-code is processed as it streams; a later error can occur after earlier moves have already run.

GRBL rejects tool-change M6 and many canned cycles. Configure pcb2gcode output accordingly, for example expanded drilling moves for a drilling file. The full rejected line is printed to the ESP32 Serial Monitor. Files should contain the intended feed, spindle, safe approach, and end commands. Starting a file selects G21/G90/G54/G49; the file can subsequently change modes. Reconfirm work zero after changing tools or using a file that modifies offsets.

Start requires GRBL Idle. It does not prove the machine was homed or the stock/tool origins are correct. Confirm machine setup and preview the G-code. Begin commissioning with motor/spindle outputs disabled, then test individual commands and an air run with your physical stop available. The HMI does not enforce a complete travel-envelope or clamp collision model.

## References

- GRBL 1.1 serial interface and overrides — https://github.com/gnea/grbl/blob/master/doc/markdown/interface.md
- GRBL jogging — https://github.com/gnea/grbl/blob/master/doc/markdown/jogging.md
- GRBL commands — https://github.com/gnea/grbl/wiki/Grbl-v1.1-Commands
- GRBL pin connections — https://github.com/gnea/grbl/wiki/Connecting-Grbl
- ESP32 Arduino core — https://docs.espressif.com/projects/arduino-esp32/en/latest/

## Validation status

The complete sketch passed a host C++17 syntax build using Arduino/ESP32 API stubs. Simulated assertions exercised comment stripping, invalid/oversized input, EOF handling, acknowledgment/status freshness, failed-probe behavior, the 14 mm offset calculation and retract command, end-of-job completion gating, GRBL error handling, and feed override bounds/bytes.

An ESP32-target build was attempted, but Arduino CLI could not download its core indexes in the execution environment. The stub build does not verify actual Arduino library ABI, ESP32 interrupt behavior, SD timing, LCD electrical compatibility, or physical motion. Compile in Arduino IDE and perform hardware commissioning before use. No physical machine tests have been performed.

The UI and sender implement the features above. Bed leveling is an informational disabled menu item. Probe speed/travel/retract and jog speeds are implementation defaults and must suit the machine. The SD supply and the LCD's input thresholds remain dependent on the exact modules.
