/* PCBMillv1.0 — Ethan and Chase
   ESP32 DevKit V1 (WROOM-32), GRBL 1.1, parallel 1602 LCD.
   Read WIRING_AND_SETUP.md before connecting the Uno or running motion.
   Root-directory SD files: .ngc, .nc, .gcode, .tap. FAT32 recommended.
   No automatic surface compensation. Probe plate height is 14 mm.
*/
#include <Arduino.h>
#include <LiquidCrystal.h>
#include <SPI.h>
#include <SD.h>
#include <math.h>

LiquidCrystal lcd(21, 22, 25, 26, 27, 13); // RS, E, LCD D4-D7
HardwareSerial grbl(2);
constexpr int ENC_A = 32, ENC_B = 33, ENC_SW = 14;
constexpr int SD_CS = 4, SD_SCK = 18, SD_MISO = 19, SD_MOSI = 23;
constexpr int GRBL_RX = 16, GRBL_TX = 17;
constexpr float PROBE_HEIGHT_MM = 14.0f;
constexpr float PROBE_TRAVEL_MM = 10.0f;
constexpr float PROBE_FEED = 30.0f;
constexpr float PROBE_RETRACT_MM = 2.0f;
constexpr int ENCODER_DIRECTION = 1; // Change to -1 to reverse the wheel.
constexpr int TRANSITIONS_PER_DETENT = 4; // Some encoders need 2.
constexpr unsigned long LINK_TIMEOUT_MS = 3000;
const float jogSteps[] = {0.01f, 0.1f, 1.0f, 10.0f};

enum Screen { BOOT, MAIN, AXIS, STEP, JOG, FILES, PREPARE, FEED,
              CONFIRM, RUNNING, BUSY, MESSAGE };
enum Task { NONE, HOMING, PROBING, ZERO_XY, UNLOCKING, JOB };
enum Action { HOME_ACTION, PROBE_ACTION, XY_ACTION, START_ACTION,
              STOP_ACTION, UNLOCK_ACTION };
void beginAction(Action requested);
void confirm(Action next);

Screen screen = BOOT, feedReturn = PREPARE;
Task task = NONE;
Action action = HOME_ACTION;
int selection = 0, axis = 0, stepIndex = 1;
String state = "Offline", message, rxLine;
String filenames[48], selectedFile;
int fileCount = 0;
File jobFile;
unsigned long jobSize = 0, jobReadPosition = 0;
unsigned long lastStatus = 0, lastPoll = 0, lastDraw = 0, bootAt = 0;
unsigned long sentAt = 0, taskStarted = 0, lastFeedWrite = 0;
bool statusSeen = false, waitingAck = false, statusPending = false;
bool afterAckStatus = false, jogWaiting = false, draining = false;
bool queryFresh = false;
bool finishPollSent = false, pauseRequested = false, probeActive = false;
bool probeSucceeded = false, overrideKnown = false;
float probeMachineZ = 0;
int macroStep = 0, feedActual = 100, feedTarget = 100;
String pendingLine;
volatile int encoderTransitions = 0;
volatile uint8_t encoderPrevious = 0;
portMUX_TYPE encoderMux = portMUX_INITIALIZER_UNLOCKED;

void IRAM_ATTR encoderISR() {
  static const int8_t table[16] = {0,-1,1,0, 1,0,0,-1, -1,0,0,1, 0,1,-1,0};
  uint8_t current = (digitalRead(ENC_A) << 1) | digitalRead(ENC_B);
  portENTER_CRITICAL_ISR(&encoderMux);
  encoderTransitions += table[(encoderPrevious << 2) | current];
  encoderPrevious = current;
  portEXIT_CRITICAL_ISR(&encoderMux);
}

bool connected() {
  return statusSeen && millis() - lastStatus < LINK_TIMEOUT_MS;
}

bool idleReady() {
  return connected() && state == "Idle" && !waitingAck && !afterAckStatus
         && task == NONE && !jogWaiting;
}

void realtime(uint8_t command) { grbl.write(command); }

void showMessage(const String &text) {
  message = text;
  screen = MESSAGE;
  selection = 0;
  Serial.println(text);
}

void stopTask(const String &reason) {
  // Reset discards all queued motion. Position may be lost; re-home afterward.
  realtime('!');
  realtime(0x18);
  if (jobFile) jobFile.close();
  task = NONE;
  waitingAck = false;
  afterAckStatus = false;
  jogWaiting = false;
  draining = false;
  pauseRequested = false;
  overrideKnown = false;
  statusSeen = false;
  statusPending = false;
  state = "Resetting";
  showMessage(reason);
}

void sendLine(const String &line) {
  if (waitingAck) return;
  pendingLine = line;
  queryFresh = false;
  grbl.print(line);
  grbl.write('\n');
  waitingAck = true;
  sentAt = millis();
  Serial.print("> "); Serial.println(line);
}

void pollStatus() {
  if (millis() - lastPoll < 250) return;
  // One outstanding query makes end-of-file and post-command Idle checks fresh.
  if (statusPending && millis() - lastPoll < 1000) return;
  statusPending = true;
  queryFresh = !waitingAck;
  lastPoll = millis();
  if (draining && !waitingAck) finishPollSent = true;
  realtime('?');
}

void handleLine(const String &line) {
  Serial.println(line);
  if (line.startsWith("<")) {
    bool requested = statusPending;
    statusPending = false;
    lastStatus = millis();
    statusSeen = true;
    int end = line.indexOf('|');
    if (end < 0) end = line.indexOf('>');
    state = line.substring(1, end);
    int ov = line.indexOf("|Ov:");
    if (ov >= 0) {
      feedActual = line.substring(ov + 4).toInt();
      overrideKnown = true;
    }
    int pn = line.indexOf("|Pn:");
    probeActive = false;
    if (pn >= 0) {
      int pnEnd = line.indexOf('|', pn + 4);
      if (pnEnd < 0) pnEnd = line.indexOf('>', pn + 4);
      probeActive = line.substring(pn + 4, pnEnd).indexOf('P') >= 0;
    }
    if (state == "Alarm" && task != NONE) {
      stopTask("GRBL alarm");
      return;
    }
    if (requested && queryFresh && !waitingAck && afterAckStatus) {
      afterAckStatus = false;
      if (state == "Idle") jogWaiting = false;
    }
    if (requested && queryFresh && jogWaiting && !waitingAck && state == "Idle") jogWaiting = false;
    if (task == JOB && draining && finishPollSent && requested && state == "Idle") {
      jobFile.close();
      task = NONE;
      draining = false;
      showMessage("Job complete");
    }
    return;
  }
  if (line.startsWith("Grbl ")) {
    if (task != NONE || waitingAck) {
      if (jobFile) jobFile.close();
      task = NONE;
      waitingAck = false;
      showMessage("GRBL restarted");
    }
    statusSeen = false;
    overrideKnown = false;
    afterAckStatus = false;
    jogWaiting = false;
    statusPending = false;
    return;
  }
  if (line.startsWith("[PRB:")) {
    float x, y, z;
    int success;
    if (sscanf(line.c_str(), "[PRB:%f,%f,%f:%d]", &x, &y, &z, &success) == 4) {
      probeMachineZ = z;
      probeSucceeded = success == 1 && isfinite(z);
    }
    return;
  }
  if (line.startsWith("ALARM:") || line.startsWith("error:")) {
    Serial.print("Rejected command: "); Serial.println(pendingLine);
    stopTask(line);
    return;
  }
  if (line == "ok" && waitingAck) {
    waitingAck = false;
    afterAckStatus = true;
    // Discard an older outstanding query before requesting the next status.
    if (task != JOB && task != NONE) ++macroStep;
  }
}

void readSerial() {
  while (grbl.available()) {
    char c = grbl.read();
    if (c == '\n') {
      rxLine.trim();
      if (rxLine.length()) handleLine(rxLine);
      rxLine = "";
    } else if (c != '\r') {
      if (rxLine.length() >= 255) {
        rxLine = "";
        stopTask("Serial overflow");
        return;
      }
      rxLine += c;
    }
  }
}

bool supportedFile(String name) {
  name.toLowerCase();
  return name.endsWith(".ngc") || name.endsWith(".nc") ||
         name.endsWith(".gcode") || name.endsWith(".tap");
}

void scanCard() {
  fileCount = 0;
  SD.end();
  if (!SD.begin(SD_CS, SPI, 4000000)) {
    showMessage("Insert SD/retry");
    return;
  }
  File root = SD.open("/");
  if (!root || !root.isDirectory()) {
    showMessage("SD root error");
    return;
  }
  File entry = root.openNextFile();
  while (entry && fileCount < 48) {
    String name = entry.name();
    int slash = name.lastIndexOf('/');
    if (slash >= 0) name = name.substring(slash + 1);
    if (!entry.isDirectory() && supportedFile(name)) filenames[fileCount++] = name;
    entry.close();
    entry = root.openNextFile();
  }
  entry.close();
  root.close();
  if (!fileCount) { showMessage("No G-code files"); return; }
  selection = 0;
  screen = FILES;
}

// Returns 1 for a command, 0 for EOF, -1 for invalid/read-failed input.
// Removes comments before serial transmission so realtime characters in comments
// cannot accidentally pause, resume, or reset GRBL.
int nextCommand(File &file, String &line) {
  line = "";
  bool comment = false, semicolon = false;
  unsigned int rawLength = 0;
  while (file.position() < file.size()) {
    int raw = file.read();
    if (raw < 0) return -1;
    char c = (char)raw;
    if (c == '\n') {
      if (comment) return -1;
      semicolon = false;
      rawLength = 0;
      if (line.length()) return 1;
      continue;
    }
    if (++rawLength > 1024) return -1;
    if (semicolon) continue;
    if (c == '(') { if (comment) return -1; comment = true; continue; }
    if (c == ')') { if (!comment) return -1; comment = false; continue; }
    if (comment) continue;
    if (c == ';') { semicolon = true; continue; }
    if (c == ' ' || c == '\t' || c == '\r') continue;
    if (c == '%' && line.length() == 0) { semicolon = true; continue; }
    // Permit only G-code words and numbers. Reject $ settings and realtime bytes.
    if (!isalnum((unsigned char)c) && c != '.' && c != '+' && c != '-') return -1;
    line += (char)toupper((unsigned char)c);
    if (line.length() > 79) return -1;
  }
  if (comment) return -1;
  return line.length() ? 1 : 0;
}

void beginAction(Action requested) {
  if (requested == STOP_ACTION) { stopTask("Stopped/re-home"); return; }
  bool canHome = requested == HOME_ACTION && connected() &&
                 (state == "Idle" || state == "Alarm") && task == NONE && !waitingAck;
  bool canUnlock = requested == UNLOCK_ACTION && connected() &&
                   state == "Alarm" && task == NONE && !waitingAck;
  if (!idleReady() && !canHome && !canUnlock) {
    showMessage("GRBL not ready"); return;
  }
  macroStep = 0;
  taskStarted = millis();
  screen = BUSY;
  if (requested == HOME_ACTION) task = HOMING;
  if (requested == UNLOCK_ACTION) task = UNLOCKING;
  if (requested == XY_ACTION) task = ZERO_XY;
  if (requested == PROBE_ACTION) {
    if (millis() - lastStatus > 750 || probeActive) {
      showMessage("Check probe pin"); return;
    }
    probeSucceeded = false;
    task = PROBING;
  }
  if (requested == START_ACTION) {
    jobFile = SD.open((String("/") + selectedFile).c_str(), FILE_READ);
    if (!jobFile || !jobFile.size()) { showMessage("File open failed"); return; }
    jobSize = jobFile.size();
    jobReadPosition = 0;
    pauseRequested = false;
    draining = false;
    finishPollSent = false;
    task = JOB;
    screen = RUNNING;
    selection = 0;
    // Establish the same coordinate system used by the HMI's zeroing routines.
    sendLine("G21 G90 G54 G49");
  }
}

void serviceTask() {
  if (task == NONE) return;
  if (!connected()) { stopTask("GRBL link lost"); return; }
  if (task != JOB && millis() - taskStarted > 180000) {
    stopTask("Operation timeout"); return;
  }
  if (waitingAck) return;
  if (task == JOB) {
    if (pauseRequested || state.startsWith("Hold") || state.startsWith("Door") || draining) return;
    if (state != "Idle" && state != "Run") return;
    String command;
    int result = nextCommand(jobFile, command);
    jobReadPosition = jobFile.position();
    if (result < 0) { stopTask("SD/line error"); return; }
    if (result == 0) {
      draining = true;
      finishPollSent = false;
      return;
    }
    sendLine(command);
    return;
  }
  // Every macro command waits for its ack and a subsequent status report.
  if (afterAckStatus || statusPending) return;
  if (task == HOMING) {
    if (macroStep == 0) sendLine("$H");
    else if (state == "Idle") { task = NONE; showMessage("Homing complete"); }
  } else if (task == UNLOCKING) {
    if (macroStep == 0) sendLine("$X");
    else { task = NONE; showMessage("Unlocked"); }
  } else if (task == ZERO_XY) {
    if (macroStep == 0) sendLine("G21 G90 G54 G49");
    else if (macroStep == 1) sendLine("G10 L20 P1 X0 Y0");
    else { task = NONE; showMessage("XY zero set"); }
  } else if (task == PROBING) {
    switch (macroStep) {
      case 0: sendLine("M5"); break;
      // $13=0 makes the PRB coordinates millimeters. This changes reporting units.
      case 1: sendLine("$13=0"); break;
      case 2: sendLine("G21 G90 G54 G49"); break;
      case 3: sendLine("G92.1"); break;
      case 4:
        sendLine(String("G91 G38.2 Z-") + String(PROBE_TRAVEL_MM, 3) +
                 " F" + String(PROBE_FEED, 1));
        break;
      case 5:
        if (!probeSucceeded) { stopTask("Probe failed"); return; }
        // PRB is in machine coordinates; write G54 Z offset from the trigger point.
        sendLine(String("G10 L2 P1 Z") + String(probeMachineZ - PROBE_HEIGHT_MM, 4));
        break;
      case 6: sendLine(String("G91 G0 Z") + String(PROBE_RETRACT_MM, 3)); break;
      case 7: sendLine("G90"); break;
      default:
        if (state == "Idle") { task = NONE; showMessage("Z zero set"); }
        break;
    }
  }
}

void serviceFeed() {
  if (!connected() || !overrideKnown || task == PROBING || task == HOMING) return;
  if (feedActual == feedTarget || millis() - lastFeedWrite < 600) return;
  int difference = feedTarget - feedActual;
  uint8_t command;
  if (difference >= 10) command = 0x91;
  else if (difference <= -10) command = 0x92;
  else if (difference > 0) command = 0x93;
  else command = 0x94;
  realtime(command);
  lastFeedWrite = millis();
  // Await the next Ov report before issuing another increment.
  overrideKnown = false;
}

void confirm(Action next) {
  action = next;
  selection = 0; // Default to Cancel.
  screen = CONFIRM;
}

void rotate(int direction) {
  if (screen == FEED) {
    feedTarget = constrain(feedTarget + direction * 5, 10, 200);
    return;
  }
  if (screen == JOG) {
    if (!idleReady()) return; // No accumulated wheel motion after releasing the wheel.
    char axisName = "XYZ"[axis];
    float travel = jogSteps[stepIndex] * direction;
    float feed = axis == 2 ? 100.0f : 300.0f;
    jogWaiting = true;
    sendLine(String("$J=G91 G21 ") + axisName + String(travel, 3) + " F" + String(feed, 0));
    return;
  }
  int count = 1;
  switch (screen) {
    case MAIN: count = 7; break;
    case AXIS: count = 4; break;
    case STEP: count = 5; break;
    case FILES: count = fileCount + 1; break;
    case PREPARE: count = 3; break;
    case RUNNING: count = 3; break;
    case CONFIRM: count = 2; break;
    default: return;
  }
  selection = (selection + direction + count) % count;
}

void click() {
  switch (screen) {
    case MAIN:
      switch (selection) {
        case 0: scanCard(); break;
        case 1: screen = AXIS; selection = 0; break;
        case 2: confirm(HOME_ACTION); break;
        case 3: confirm(PROBE_ACTION); break;
        case 4: confirm(XY_ACTION); break;
        case 5: confirm(UNLOCK_ACTION); break;
        case 6: showMessage("Leveling off"); break;
      }
      break;
    case AXIS:
      if (selection == 3) { screen = MAIN; selection = 0; }
      else { axis = selection; screen = STEP; selection = stepIndex; }
      break;
    case STEP:
      if (selection == 4) { screen = AXIS; selection = axis; }
      else { stepIndex = selection; screen = JOG; }
      break;
    case JOG:
      realtime(0x85); // GRBL jog cancel.
      screen = STEP; selection = stepIndex;
      break;
    case FILES:
      if (selection == fileCount) { screen = MAIN; selection = 0; }
      else { selectedFile = filenames[selection]; screen = PREPARE; selection = 0; }
      break;
    case PREPARE:
      if (selection == 0) { feedReturn = PREPARE; screen = FEED; }
      else if (selection == 1) confirm(START_ACTION);
      else { screen = MAIN; selection = 0; }
      break;
    case FEED: screen = feedReturn; selection = 0; break;
    case RUNNING:
      if (selection == 0) { feedReturn = RUNNING; screen = FEED; }
      else if (selection == 1) {
        if (state == "Hold:0") { pauseRequested = false; realtime('~'); }
        else if (!pauseRequested && !state.startsWith("Hold") && !state.startsWith("Door")) {
          pauseRequested = true; realtime('!');
        }
      } else confirm(STOP_ACTION);
      break;
    case CONFIRM:
      if (selection == 1) beginAction(action);
      else if (task == JOB) { screen = RUNNING; selection = 0; }
      else { screen = MAIN; selection = 0; }
      break;
    case MESSAGE: screen = MAIN; selection = 0; break;
    default: break;
  }
}

void readEncoder() {
  int detents = 0;
  portENTER_CRITICAL(&encoderMux);
  detents = encoderTransitions / TRANSITIONS_PER_DETENT;
  encoderTransitions %= TRANSITIONS_PER_DETENT;
  portEXIT_CRITICAL(&encoderMux);
  // Drop fast extra detents in jog mode to prevent a backlog of moves.
  if (screen == JOG && detents) rotate((detents > 0 ? 1 : -1) * ENCODER_DIRECTION);
  else {
    detents = constrain(detents, -10, 10);
    while (detents != 0) {
      int direction = detents > 0 ? 1 : -1;
      rotate(direction * ENCODER_DIRECTION);
      detents -= direction;
    }
  }
  static bool lastRaw = HIGH, stable = HIGH, longHandled = false;
  static unsigned long changed = 0, pressed = 0;
  bool raw = digitalRead(ENC_SW);
  if (raw != lastRaw) { changed = millis(); lastRaw = raw; }
  if (millis() - changed > 30 && raw != stable) {
    stable = raw;
    if (stable == LOW) { pressed = millis(); longHandled = false; }
    else if (!longHandled) click();
  }
  if (stable == LOW && !longHandled && millis() - pressed > 1200) {
    longHandled = true;
    if (task != NONE || screen == JOG || jogWaiting) stopTask("Stopped/re-home");
    else { screen = MAIN; selection = 0; }
  }
}

void lcdRow(int row, String value) {
  static String previous[2];
  value = value.substring(0, 16);
  while (value.length() < 16) value += ' ';
  if (previous[row] == value) return;
  previous[row] = value;
  lcd.setCursor(0, row);
  lcd.print(value);
}

void drawScreen() {
  if (millis() - lastDraw < 100) return;
  lastDraw = millis();
  String top, bottom;
  const char *mainItems[] = {"Run SD file", "Manual jog", "Auto home", "Probe zero",
                             "Set XY zero", "Unlock alarm", "Bed leveling"};
  const char *actions[] = {"Home machine?", "Probe 14mm?", "Zero XY here?",
                           "Start file?", "Stop / reset?", "Unlock alarm?"};
  switch (screen) {
    case BOOT: top = "PCBMillv1.0"; bottom = "by Ethan and Chase"; break;
    case MAIN: top = connected() ? state : "GRBL offline"; bottom = String(">") + mainItems[selection]; break;
    case AXIS: top = "Select jog axis"; bottom = selection == 3 ? ">Back" : String(">Axis ") + "XYZ"[selection]; break;
    case STEP:
      top = String("Jog ") + "XYZ"[axis] + " increment";
      bottom = selection == 4 ? ">Back" : String(">") + String(jogSteps[selection], 2) + " mm";
      break;
    case JOG:
      top = String("Jog ") + "XYZ"[axis] + " " + String(jogSteps[stepIndex], 2) + "mm";
      bottom = jogWaiting ? "Moving..." : "Turn / click out";
      break;
    case FILES:
      top = "Select SD file";
      bottom = selection == fileCount ? ">Back" : String(">") + filenames[selection];
      break;
    case PREPARE:
      top = selectedFile;
      if (selection == 0) bottom = String(">Feed ") + feedTarget + "%";
      if (selection == 1) bottom = ">Start job";
      if (selection == 2) bottom = ">Back";
      break;
    case FEED:
      top = String("Feed target ") + feedTarget + "%";
      bottom = String("Now ") + feedActual + "% Click=OK";
      break;
    case CONFIRM: top = actions[action]; bottom = selection ? ">Yes" : ">Cancel"; break;
    case RUNNING: {
      unsigned int percent = jobSize ? (uint64_t)jobReadPosition * 100 / jobSize : 0;
      top = String("Sent ") + percent + "% F" + feedActual + "%";
      if (selection == 0) bottom = ">Adjust feed";
      if (selection == 1) bottom = state == "Hold:0" ? ">Resume" : ">Pause";
      if (selection == 2) bottom = ">Stop job";
      if (draining) top = "Finishing motion";
      if (pauseRequested || state.startsWith("Hold")) top = "Paused/holding";
      break;
    }
    case BUSY:
      top = task == HOMING ? "Homing..." : task == PROBING ? "Probing Z..." : "Setting up...";
      bottom = "Hold btn=abort";
      break;
    case MESSAGE: top = message; bottom = "Click for menu"; break;
  }
  // The requested author line has 18 characters. Scroll just that line at boot.
  if (screen == BOOT) {
    unsigned long elapsed = millis() - bootAt;
    int offset = elapsed < 1500 ? 0 : elapsed < 2500 ? 1 : 2;
    bottom = bottom.substring(offset);
  }
  lcdRow(0, top);
  lcdRow(1, bottom);
}

void setup() {
  Serial.begin(115200);
  grbl.begin(115200, SERIAL_8N1, GRBL_RX, GRBL_TX);
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encoderPrevious = (digitalRead(ENC_A) << 1) | digitalRead(ENC_B);
  attachInterrupt(digitalPinToInterrupt(ENC_A), encoderISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_B), encoderISR, CHANGE);
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  lcd.begin(16, 2);
  bootAt = millis();
}

void loop() {
  readSerial();
  if (screen == BOOT && millis() - bootAt > 4000) screen = MAIN;
  if (screen != BOOT) readEncoder();
  serviceTask();
  serviceFeed();
  // Poll after task processing so a completed command can request a fresh status.
  pollStatus();
  if (task == NONE && waitingAck && millis() - sentAt > 10000) stopTask("No GRBL reply");
  drawScreen();
  delay(1);
}
